<p align="center">
  <a href="https://youtube.com/codingwala">
    <img src="https://www.codingwala.in/assets/icon/android-chrome-192x192.png" alt="Coding Wala">
  </a>

  <h3 align="center"><a href="https://youtube.com/codingwala">Coding Wala</a></h3>

  <p align="center">
    Selfbot Made By <b>Coding Wala</b><br>AKA <b>Bhuvnesh</b>
    <br>
    <a href="https://www.codingwala.in/dc">Report bug</a>
    ·
    <a href="https://www.codingwala.in/dc">Request feature</a>
  </p>
</p>


## Quick start

1. Fork The Repl
2. Run `sh install.sh` in Shell 
3. Open `config.json` file
4. Fill Your Desired Data
5. Run The Repl

### If Got any trouble running that [Report Here](https://www.codingwala.in/dc)

## Thanks

Try Not To skid 🙏

## Copyright and license

Code copyright 2021 Coding Wala. Code released under the [MIT License](https://reponame/blob/master/LICENSE).

Enjoy 🤘